# derivatives

#def tanh():